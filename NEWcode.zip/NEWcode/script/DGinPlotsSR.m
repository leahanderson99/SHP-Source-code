%plots the heatmap Figure 5F and Figures 6B&C
%written by Leah Anderson, 2021

function DGinPlotsSR(Ginplot,parameters)
%% load rates and variables

load('script/data/sr','sr')

%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW
a = 3;                                         % a selects the row of sr data structure that we are plotting (specific values of srPtoC/srCtoP, or V1/V2, or K1)
    solSSPC = sr(a).solSSPC;
    solSSPnoC = sr(a).solSSPnoC;
    switchingval1 = sr(a).storesr(1);
    %switchingval2 = sr(a).storesr(2);
    str1 = sprintf('%0.2f' ,switchingval1);
    %str2 = sprintf('%0.2f' ,switchingval2);


    if isempty(Ginplot)
        Ginplot = solSSPC(end,2);
    end

    SS = solSSPC(solSSPC(:,2)==double(Ginplot),:);
    SSnoC = solSSPnoC(solSSPnoC(:,2)==double(Ginplot),:);

%% plots

% [~,axF1] = plot_SS(parameters,SS,15+2,19+2,'r_{up}^g [g/gDW/h]');
% title(axF1,'Main Figure 5D')
% hold(axF1, 'off');  
% [~,axF2] = plot_SS(parameters,SS,16+2,20+2,'r_{over}^a [g/gDW/h]');
% title(axF2,'Supporting Figure S6B')
% hold(axF2, 'off');  
% [~,axF3] = plot_SS(parameters,SS,17+2,21+2,'r_{up}^a [g/gDW/h]');
% title(axF3,'Supporting Figure S6D')
% hold(axF3, 'off');  
% 
% aplot = SS(:,1);
% bplot = SS(:,5)+SS(:,6);
% % cplot = SS(:,7);
% cplot = SS(:,7)+SS(:,8);
% SSa = [aplot,bplot,cplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
% [~,axF4] = plot_SS(parameters,SSa,2,3,'Btot [gDW/L]');
% title(axF4,'Main Figure 5F')
% hold(axF4, 'off');  

%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW

aplot = SS(:,1);
%bplot = SS(:,1).*SS(:,6);
bplot = SS(:,1).*SS(:,6)+SS(:,1).*SS(:,8);
SSa = [aplot,bplot,0.*aplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
aplot = SSnoC(:,1);
%bplot = SSnoC(:,1).*SSnoC(:,6);
bplot = SSnoC(:,1).*SSnoC(:,6)+SSnoC(:,1).*SSnoC(:,8);
SSnoCa = [aplot,bplot,0.*aplot,0.*aplot,SSnoC(:,5),0.*aplot,SSnoC(:,7)];
[~,axF5] = plot_SSCnoC(parameters,SSa,2,SSnoCa,2,'DHp+DHc [gDW/L/h]');
title(['K_a =', str1])
hold(axF5, 'off');  

aplot = SS(:,1);
%bplot = SS(:,6)./Ginplot;
bplot = (SS(:,6)+SS(:,8))./Ginplot;
SSa = [aplot,bplot,0.*aplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
aplot = SSnoC(:,1);
%bplot = SSnoC(:,6)./Ginplot;
bplot = (SSnoC(:,6)+SSnoC(:,8))./Ginplot;
SSnoCa = [aplot,bplot,0.*aplot,0.*aplot,SSnoC(:,5),0.*aplot,SSnoC(:,7)];
[~,axF6] = plot_SSCnoC(parameters,SSa,2,SSnoCa,2,'(Hp+Hc)/G_{in} [gDW/g]');
title(['K_a=', str1])
hold(axF6, 'off'); 

end


%SS = solSSPC(solSSPC(:,2)==double(Ginplot) & solSSPC(:,1)==double(Dinplot),:);

