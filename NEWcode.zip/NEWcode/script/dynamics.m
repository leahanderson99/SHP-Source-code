%[T,X,dx,r] = dynamics(run_estimation,batchChemFed,producer,cleaner,hproteinP)
%generates the time evolution of the variables (G,A,Bp,H,Bc) in the bioreactor.
%
%Inputs:
%run_estimation = 0 imports already estimated parameters (to speed up evaluation), 1 estimate parameters from data, 2 plot already existing estimation
%batchChemFed = 0 simulates batch, 1 chemostat, 2 fedbatch
%producer = 0 simulation without producer, 1 with producer
%cleaner = 0 simulation without cleaner, 1 with cleaner
%hproteinP = 0 simulation without H protein, 1 with H protein
%
%Outputs:
%T time vector
%X = [G,A,BP,H,BC]; variables vector
%dx = [dG,dA,dBP,dH,dBC]; rate vector
%r = [muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg]; internal rate vector
%
%This file was written by Marco Mauri, 2019
%

function [T,X,dx,r] = dynamics(run_estimation,batchChemFed,producer,cleaner,hproteinP,srBPtoBC,srBCtoBP)  %V1,V2)

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

%define the model
blackboxmodel = @test;          %USE @test for Hill fn witching, @model for constant switching

%parameters
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP,srBPtoBC,srBCtoBP);       %V1,V2

%% dynamics
if parameters.par(1)==1
    tspan = 0:1:400;
elseif parameters.par(1)==0
    tspan = 0:0.2:25;
end
s0 = parameters.x0;
[T,X,dx,r] = simulate_dynamics(blackboxmodel,parameters,tspan,s0);
plot_dynamics(T,X,r,parameters)
end