%plot_DGinMap
%plots the heat-map (D,Gin) coming form the steady-state analysis of 
%the consortium in chemostat operating in continuous mode
%
%Outputs:
%Plots of heat map D-Gin
%
%This file was written by Leah Anderson, 2021
%

function plot_DGinMapSR

load('script/data/sr','sr')
a = 1;
switchingval1 = sr(a).storesr(1);
%switchingval2 = sr(a).storesr(2);
str1 = sprintf('%0.2f' ,switchingval1);
%str2 = sprintf('%0.2f' ,switchingval2);


rd = 'r';
gr = [0.4660 0.6740 0.1880];
og = [255/255 153/255 51/255];

pk = [241/255 156/255 187/255];

%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg] NEW
solSSPC = sr(1).solSSPC;

D=1;
Gin=2;
Bp=5;
Bc=7;
sizep=85;
markertype='o';

%% figure regarding the coexistence of P and C

fig = figure;
axF = axes('Parent', fig);
hold(axF, 'on');  
hms=msgbox('Please wait. Plotting in progress...');

k=0;
for i=1:size(solSSPC,1)
    if solSSPC(i,Bp)==0 && solSSPC(i,Bc)==0 
        scatter(solSSPC(i,D),solSSPC(i,Gin),sizep,'k','filled',markertype)
    
    elseif solSSPC(i,Bp)~=0 && solSSPC(i,Bc)~=0 
        scatter(solSSPC(i,D),solSSPC(i,Gin),sizep,pk,'filled',markertype)
    
    elseif solSSPC(i,Bp)==0 && solSSPC(i,Bc)~=0
        scatter(solSSPC(i,D),solSSPC(i,Gin),sizep,og,'filled',markertype)
    
    elseif solSSPC(i,Bp)~=0 && solSSPC(i,Bc)==0
        scatter(solSSPC(i,D),solSSPC(i,Gin),sizep,gr,'filled',markertype)
    end
    k=k+1;
    hold(axF, 'on'); 
end

xlabel('D [1/h]')
ylabel('Gin [g/L]')
grid on
box on
set(gca,'FontSize',15)
pbaspect([1 1 1])
axis tight
title(['Phase Diagram- K_a =', str1])
% title(axF,'Main Figure 5B')
drawnow
hold(axF, 'off'); 

if isvalid(hms); delete(hms); end

% %% figure heat map
% 
% xt = solSSPC(:,1); %D
% yt = solSSPC(:,2); %Gin
% zt = solSSPC(:,1).*solSSPC(:,6); %D*H
% 
% xsize = size(find(xt==xt(end)),1);
% ysize = size(xt,1)/xsize;
% 
% x = reshape(xt, xsize, ysize);
% y = reshape(yt, xsize, ysize);
% z = reshape(zt, xsize, ysize);
% 
% fig2 = figure;
% axF2 = axes('Parent', fig2);
% hold(axF2, 'on'); 
% hms=msgbox('Please wait. Plotting in progress...');
% tri = delaunay(x,y); % Little triangles
% trisurf(tri, x, y, z); % Plot it with TRISURF
% % Clean it up
% shading interp
% colorbar EastOutside
% axis tight
% colormap gray
% view(2)
% xlabel('D [1/h]')
% ylabel('G_{in}^* [g/L]')
% zlabel('D \cdot H [g/(L h)]')
% set(gca,'FontSize',15)
% title('Main Figure 6A')
% drawnow
% hold(axF2, 'off'); 
% 
% if isvalid(hms); delete(hms); end


end
