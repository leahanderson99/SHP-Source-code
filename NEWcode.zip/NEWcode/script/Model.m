%[dx,r] = Model(t,x,parameters)
%defines the ODE system of equations
%
%Inputs: 
%t, time vector
%x, variable vector (G,A,Bp,H,Bc)
%parameters, structure including the parameters values
%
%Outputs:
%dx = [dG,dA,dBP,dH,dBC]; rate vector
%r = [muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg]; internal rate vector
%
%This file was written by Marco Mauri, 2019
%% and modified by Leah Anderson, 2021

function [dx,r] = Model(t,x,parameters)

%parameters
batchChemFed = parameters.par(1);
if batchChemFed==2  
    fedbatch = 0;
else
    fedbatch = 1;
end
producer = parameters.par(2);
cleaner = parameters.par(3);
hproteinP = producer*parameters.par(4);
kg = parameters.par(5);
Kg = parameters.par(6);
Ta = parameters.par(7);
n = parameters.par(8);
kover = parameters.par(9);
l = parameters.par(10);
ka = parameters.par(11);
Ka = parameters.par(12);
Tg = parameters.par(13);
m = parameters.par(14);
Yg = parameters.par(15);
Ya = parameters.par(16);
Yh = parameters.par(17);
Cm = parameters.par(18);
kDPTS = parameters.par(19);
kACS = parameters.par(20);
KACS = parameters.par(21);
alphaglc = parameters.par(22);
alphaace = parameters.par(23);
kdeg = parameters.par(24);
G0Batch = batchChemFed.*parameters.par(25);
D = batchChemFed.*parameters.par(26);
Gin = batchChemFed.*parameters.par(27);
G0fedBatch = batchChemFed.*parameters.par(28);
srBPtoBC = cleaner*parameters.par(29);
srBCtoBP = cleaner*parameters.par(30);

%variables
G = x(1);
A = x(2);
BP = producer*x(3);
H = hproteinP*producer*x(4);
BC = cleaner*x(5);
HC = hproteinP*cleaner*x(6);

%internal rates
rgupP = kg*(G/(G+Kg)) * ((Ta^n)/((Ta^n)+(A)^n));
raoverP = kover*heaviside(rgupP-l)*(rgupP-l);
raupP = (ka)*(A/(A+Ka)) * (Tg^m)/((Tg^m)+(rgupP)^m);
rgupC = (kDPTS*(G/(G+Kg)) * ((Ta^n)/((Ta^n)+(A)^n)));
raoverC = kover*heaviside(rgupC-l)*(rgupC-l);
raupC = (ka)*(A/(A+Ka)) * ((Tg^m)/((Tg^m)+(rgupC)^m)) + kACS*(A/(A+KACS));
rH = (hproteinP*Yh).*(Yg.*rgupP + Ya.*(raupP-raoverP));
kdeg = Cm*Yg;



%ODE
dG = fedbatch.*(-rgupP.*BP -rgupC.*BC + D.*Gin -D.*G);
dA = (raoverP - raupP).*BP + (raoverC - raupC).*BC -D.*A;
dBP = (1-hproteinP*Yh).*(Yg.*rgupP + Ya.*(raupP-raoverP)).*BP -D.*BP -kdeg.*BP - srBPtoBC.*BP + srBCtoBP.*BC;
dH = (hproteinP*Yh).*(Yg.*rgupP + Ya.*(raupP-raoverP)).*BP - D.*H -kdeg.*H - srBPtoBC.*H + srBCtoBP.*HC;
dBC = (Yg.*rgupC +Ya.*(raupC-raoverC)).*BC -D.*BC - kdeg.*BC + srBPtoBC.*BP - srBCtoBP.*BC;
dHC = srBPtoBC.*H -srBCtoBP.*HC -kdeg.*HC -D.*HC;

%remove eventual numerical imprecisions and compute growth rates
if BP==0
    raupP=0;
    rgupP=0;
    raoverP=0;
    rH=0;
    muP = 0;
else
    muP = (Yg.*rgupP + Ya.*(raupP-raoverP)).*(BP/(BP+H))- kdeg + srBCtoBP.*((BC+HC)/(BP+H)) - srBPtoBC;
end

if BC==0
    raupC=0;
    rgupC=0;
    raoverC=0;
    muC = 0;
else
    muC = (Yg.*rgupC +Ya.*(raupC-raoverC)).*(BC/(BC+HC)) - kdeg + srBPtoBC.*((BP+H)/(BC+HC)) - srBCtoBP;
end

%store results
dx = [dG;dA;dBP;dH;dBC;dHC];
r = [muP;muC;rgupP;raoverP;raupP;rH;rgupC;raoverC;raupC;kdeg];

end


