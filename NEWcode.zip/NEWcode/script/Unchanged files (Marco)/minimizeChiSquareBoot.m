%[chisquareTotal] = minimizeChiSquareBoot(X,blackboxmodel,datax1,datay1,datax2,datay2,datax3,datay3)
%computes the total chi-square of the three sets of data used to obtain (Ta,n,Tg,m)
%
%Inputs:
%X, vector cotaining (Ta,n,Tg,m)
%blackboxmodel, is the model name
%datax1,datay1,datax2,datay2,datax3,datay3, the (x,y) values of the three datasets
%
%Output:
%chisquareTotal, total chi-square of the three sets of data
%
%This file was written by Marco Mauri, 2019
%

function [chisquareTotal] = minimizeChiSquareBoot(X,blackboxmodel,datax1,datay1,datax2,datay2,datax3,datay3)

%parameters
run_estimation = 0;
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);

%compute parameters
[chisquareData1,~,~,~] = fitParameters(X,blackboxmodel,parameters,datax1,datay1,1,0);
[chisquareData2,~,~,~] = fitParameters(X,blackboxmodel,parameters,datax2,datay2,2,0);
[chisquareData3,~,~,~] = fitParameters(X,blackboxmodel,parameters,datax3,datay3,3,0);

%chisquare
chisquareTotal = chisquareData1.^2+chisquareData2.^2+chisquareData3.^2;

end