%[fittedParameters] = findParameters(blackboxmodel,run_estimation)
%fits exprimental data to find the values of Ta, n, Tg, m
%
%Inputs:
%blackboxmodel, is the model name
%run_estimation, 1 estimate parameters from data, 2 plot already existing estimation
%
%Output:
%fittedParameters, vector containing (Ta,n,Tg,m)
%
%This file was written by Marco Mauri, 2019
%

function [fittedParameters] = findParameters(blackboxmodel,run_estimation)

%options for fminsearchbnd
options = optimset('TolFun',1e-2,'TolX',1e-2,'MaxIter',100,'Display','off');
lb = [0.2,              0.2,          0.05,     0.2];
X0 = [3.52,           1,       0.25,   1];
ub = [5,                3,            1,        3];

%chi square
figure('units','normalized','outerposition',[0 0 1 2/3])
[fittedParameters] = fminsearchbnd(@(X) minimizeChiSquare(X,blackboxmodel,run_estimation),X0,lb,ub,options);
fittedParameters(1) = round(fittedParameters(1),2);
fittedParameters(2) = round(fittedParameters(2),1);
fittedParameters(3) = round(fittedParameters(3),2);
fittedParameters(4) = round(fittedParameters(4),1);
fprintf('Ta = %f, n = %f, Tg = %f, m = %f \n',fittedParameters(1),fittedParameters(2),fittedParameters(3),fittedParameters(4))
save('script/data/fittedParameters','-v6','fittedParameters')

end