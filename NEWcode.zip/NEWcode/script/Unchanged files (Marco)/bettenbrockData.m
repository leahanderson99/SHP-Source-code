%bettenbrockData
%compares the simulation of the model to the data of Steinsiek and Bettenbrock https://doi.org/10.1128/JB.01502-12
%
%This file was written by Marco Mauri, 2019
%

function bettenbrockData

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

%define the model
blackboxmodel = @Model;

%initialize parameters
run_estimation = 0;
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);
%experimental glc
parameters.x0(1) = 3.6;

parameters.plot(1) = 10;

%import data
datBMu = load('data/ExpBettenbrockMu.mat');
dataMu = datBMu.ExpBettenbrockMu(:,2);
datBGlcUp = load('data/ExpBettenbrockGlcUp.mat');
dataGlcUp = parameters.par(22).*datBGlcUp.ExpBettenbrockGlcUp(:,2)./1000;
datBAceOver = load('data/ExpBettenbrockAceOver.mat');
dataAceOver = parameters.par(23).*datBAceOver.ExpBettenbrockAceOver(:,2)./1000;

%ratios
ratioMu = dataMu./dataMu(1,1);
ratioGlcUp = dataGlcUp./dataGlcUp(1,1);
ratioAceOver = dataAceOver./dataAceOver(1,1);

%find new kg
kgold = parameters.par(5);
muRatioModel = zeros(size(ratioGlcUp,1),1);
raceRatioModel = zeros(size(ratioGlcUp,1),1);
for i=1:size(ratioGlcUp,1)
    parameters.par(5) = ratioGlcUp(i).*kgold;
    %dyamics
    tspan = 0:0.1:1;
    [~,~,~,r] = simulate_dynamics(blackboxmodel,parameters,tspan,parameters.x0);
    %store results
    if i==1
       muold = r(1,1); 
       rold = r(1,4)-r(1,5);
    end
    muRatioModel(i) = r(1,1)./muold;
    raceRatioModel(i) = (r(i,4)-r(i,5))./rold;
end

%plots
subplot(2,2,3)
scatter(muRatioModel,ratioMu,60,'filled','MarkerEdgeColor','b','MarkerFaceColor','b')
hold on
scatter(muRatioModel(1),ratioMu(1),100,'d','r','MarkerFaceColor','r')
rline=refline(1,0);
rline.Color = 'k';
rline.LineStyle = '--';
xlabel('Predicted growth rate ratio')
ylabel('Measured growth rate ratio')
xlim([0 inf])
ylim([0 inf])
grid on
box on
legend('Mutants','WT','Reference','Location','northwest')
title('Main Figure 3C')
drawnow

subplot(2,2,4)
scatter(raceRatioModel(1:end-1),ratioAceOver(1:end-1),60,'filled','MarkerEdgeColor','b','MarkerFaceColor','b')
hold on
scatter(raceRatioModel(1),ratioAceOver(1),100,'d','r','MarkerFaceColor','r')
rline=refline(1,0);
rline.Color = 'k';
rline.LineStyle = '--';
xlabel('Predicted acetate overflow rate ratio')
ylabel('Measured acetate overflow rate ratio')
xlim([0 inf])
ylim([0 inf])
grid on
box on
legend('Mutants','WT','Reference','Location','northwest')
title('Main Figure 3D')
drawnow

end