%plot_parametersfit(blackboxmodel)
%plots the data and the model prediction for the datasets used to fit (Ta,n,Tg,m)
%
%Input:
%blackboxmodel, is the model name
%
%Output:
%plots experimental data and model prediction of Glc uptake rate, Net Ace rate and
%Growth rate as a function of Acetate concentration
%
%This file was written by Marco Mauri, 2019
%

function plot_parametersfit(blackboxmodel)
%%
%parameters
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,0,batchChemFed,producer,cleaner,hproteinP);
dat = load('data/fittedParameters.mat');
parameters.par(7) = round(dat.fittedParameters(1),2);

% load
load('data/DataxsA1','DataxsA1')
load('data/observedData1','observedData1')
load('data/expectedData1','expectedData1')
load('data/DataxsA2','DataxsA2')
load('data/observedData2','observedData2')
load('data/expectedData2','expectedData2')
load('data/DataxsA3','DataxsA3')
load('data/observedData3','observedData3')
load('data/expectedData3','expectedData3')

figure('units','normalized','outerposition',[0 0 1 2/3]) 
subplot(1,3,1);
semilogx(DataxsA3,expectedData3,'-r','LineWidth',3);
grid on
hold on
scatter(DataxsA3,observedData3,50,'k','filled');
legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
xlabel('Acetate [g/L]')
ylabel('Growth rate [1/h]')
set(gca,'fontsize',12)
set(gca,'LineWidth',1)
title('Main Figure 2C')
drawnow

subplot(1,3,2);
semilogx(DataxsA1,expectedData1,'-r','LineWidth',3);
grid on
hold on
scatter(DataxsA1,observedData1,50,'k','filled');
legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
xlabel('Acetate [g/L]')
ylabel('Glc uptake rate [1/h]')
set(gca,'fontsize',12)
set(gca,'LineWidth',1)
title('Main Figure 2C')
drawnow

subplot(1,3,3);
semilogx(DataxsA2,expectedData2,'-r','LineWidth',3);
grid on
hold on
scatter(DataxsA2,observedData2,50,'k','filled');
legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
xlabel('Acetate [g/L]')
ylabel('Net Ace uptake rate [1/h]')
set(gca,'fontsize',12)
set(gca,'LineWidth',1)
title('Main Figure 2C')
drawnow

%rsquare
r1 = rsq(observedData1,expectedData1);
r2 = rsq(observedData2,expectedData2);
r3 = rsq(observedData3,expectedData3);

fprintf('r2(rgup) = %f, r2(race) = %f, r2(rmu) = %f \n',r1,r2,r3)
%%
end