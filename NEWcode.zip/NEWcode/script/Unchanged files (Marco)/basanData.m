%basanData
%compares the simulation of the model to the data of Bssan et al. https://doi.org/10.1038/nature15765
%
%This file was written by Marco Mauri, 2019
%

function basanData

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'));

%define the model
blackboxmodel = @Model;

%initialize parameters
run_estimation = 0;
batchChemFed = 1;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);

parameters.plot(1) = 10;
hms=msgbox('Please wait. Calculation in progress...');

%load data
dat2 = load('data/ExpDataBasan2.mat');
datXB2 = log(2).*dat2.ExpDataBasan2(:,1);
datYB2 = dat2.ExpDataBasan2(:,2);
dat1 = load('data/ExpDataBasan1.mat');
datXB1 = log(2).*dat1.ExpDataBasan1(:,1);
datYB1 = dat1.ExpDataBasan1(:,2);

%generate grid
Ginplot = 20;
heatmapparam = struct();
heatmapparam.Din = 0;
heatmapparam.Dfin = 0.7-0.02;
heatmapparam.Dstep = 0.01;
heatmapparam.Gin = 20;
heatmapparam.Gfin = 20.5;
heatmapparam.Gstep = 0.5;

[solBasanYg2] = generateDGinMap(blackboxmodel,parameters,heatmapparam);

% compute muhat = Y_g *(l-Cm)
muhat = parameters.par(15)*(parameters.par(10)-parameters.par(18));

% compute muhat2 
coefficients2 = polyfit(datXB2,datYB2, 1);
muhat2 = roots(coefficients2);

%rescale to match unknown Y axis
SS2 = solBasanYg2(solBasanYg2(:,2)==double(Ginplot),:);
ryX = [round(SS2(:,1)/muhat,2),SS2(:,16)];
ryXa = round(datXB2(end)./muhat2,2);
rescaleFactorY = ryX(ryX(:,1)==ryXa,2)./datYB2(end);

%find second Yg
YgBasan2 =parameters.par(15);
parameters.par(15) = 0.63*YgBasan2;
YgBasan1 = parameters.par(15);
[solBasanYg1] = generateDGinMap(blackboxmodel,parameters,heatmapparam);
SS1 = solBasanYg1(solBasanYg1(:,2)==double(Ginplot),:);

%prepare to plot
SS2(SS2(:,1)./muhat>=(datXB2(end)./muhat2+(SS2(2,1)./muhat-SS2(1,1)./muhat)),:)=[];
SS1(SS1(:,1)./muhat>=(datXB1(end)./muhat2+(SS1(2,1)./muhat-SS1(1,1)./muhat)),:)=[];

subplot(2,2,2)
grid on
scatter(datXB2./muhat2,rescaleFactorY.*datYB2,80,'g','filled');
hold on
scatter(datXB1./muhat2,rescaleFactorY.*datYB1,80,'r','filled');
xlabel('$\mu/\hat{\mu}$','Interpreter','latex')
box on
set(gca,'FontSize',parameters.plot(1))
axis tight
xlim([0 inf])
ylim([0 inf])
plot_SS_holdon(parameters,SS2,16,'r_{over}^a [g/gDW/h]',muhat)
plot_SS_holdon(parameters,SS1,16,'r_{over}^a [g/gDW/h]',muhat)
xlim([0 1.5])
ylim([0 0.08])
yyaxis right
ylabel('r_{over}^a [mM/OD/h]')
ylim([0 0.08/rescaleFactorY]);
legend('Data','Data','Model','Model','Location','northwest')
title('Main Figure 3B')
drawnow

if isvalid(hms); delete(hms); end

fprintf('Yg1 = %f, Yg2 = %f, Rescale factor y axis = %f\n',YgBasan2,YgBasan1,rescaleFactorY)


end