%enjalbertData
%compares the simulation of the model to the data of Enjalbert et al. https://doi.org/10.1038/srep42135
%
%This file was written by Marco Mauri, 2019
%

function enjalbertData

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

%define the model
blackboxmodel = @Model;

%initialize parameters
run_estimation = 0;
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);
parameters.par(7) = 3.4841; %Ta
parameters.par(13) = 0.2529; %Tg

parameters.plot(1) = 10;

dat = load('data/ExpEnjalbertBatch.mat');
datXB = dat.DataEnjBatch(:,2);
datYB = dat.DataEnjBatch(:,1);

datG = load('data/ExpEnjalbertBatchG.mat');
datXG = datG.DataEnjBatchG(:,1);
datYG = datG.DataEnjBatchG(:,2);

datA = load('data/ExpEnjalbertBatchA.mat');
datXA = datA.DataEnjBatchA(:,1);
datYA = datA.DataEnjBatchA(:,2);

%dynamics
tspan = 0:0.1:8.7;
[T,X,~,~] = simulate_dynamics(blackboxmodel,parameters,tspan,parameters.x0);

subplot(2,2,1)
scatter(datXB,datYB./(20*1e-3),60,'g','filled');
hold on
grid on
scatter(datXG,datYG.*parameters.par(22)./1000,60,'b','filled');
scatter(datXA,(datYA.*parameters.par(23)./1000)-0.013,60,'r','filled');
plot(T,X(:,1),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(1,:));
plot(T,X(:,2),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(2,:));
plot(T,X(:,3)+X(:,4),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(3,:));
legend('G data','A data','B data','G model','A model','B model')
xlabel('Time [h]')
ylabel('[g/L]')
box on
set(gca,'FontSize',parameters.plot(1))
axis tight
title('Main Figure 3A')
drawnow

end