%[rs]=rsq(ydata,yestimation)
%computes the rsquare
%
%Input:
%ydata, observed data
%yestimation, estimated data
%
%Output:
%rs, coefficient of determination
%
%This file was written by Marco Mauri, 2019
%

function [rs]=rsq(ydata,yestimation)
    Sres=sum( (ydata-yestimation).^2 );
    Stot=sum( (ydata-mean(ydata)).^2 );
    rs=1-Sres/Stot;     
end
