%fedbatch
%generates and plots the time evolution of the variables in the
%bioreactor operating in fed-batch mode
%
%Outputs:
%log-plot time-evelution of the fed-batch case for Btot and H in the
%presence and absence of cleaner
%
%This file was written by Marco Mauri, 2019
%

function fedbatch

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

%define the model
blackboxmodel = @Model;

%in the presence of cleaner
run_estimation = 0;
batchChemFed = 2;
producer = 1;
cleaner = 1;
hproteinP = 1;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);
tspan = 0:0.1:50;
s0 = parameters.x0;
[T,X,dx,r] = simulate_dynamics(blackboxmodel,parameters,tspan,s0);

%in the absence cleaner
run_estimation = 0;
batchChemFed = 2;
producer = 1;
cleaner = 0;
hproteinP = 1;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);
tspan = 0:0.1:50;
s0 = parameters.x0;
[TnoC,XnoC,dxnoC,rnoC] = simulate_dynamics(blackboxmodel,parameters,tspan,s0);

%plot
fig = figure;
axF = axes('Parent', fig);
hold(axF, 'on');  
plot_dynamicsFedBatch(T,X,XnoC,parameters)
title(axF,'Main Figure 7A')
drawnow
hold(axF, 'off'); 

end