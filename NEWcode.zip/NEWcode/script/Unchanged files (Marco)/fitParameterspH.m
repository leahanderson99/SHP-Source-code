%[chisquareData] = fitParameterspH(X,blackboxmodel,dataset,plotfigure)
%computes the chi-square to obtain Ta
%
%Inputs:
%X is Ta
%blackboxmodel, is the model name
%dataset, is the dataset number
%plotfigure, 0 does not plots the figure, 1 plots the figure
%
%Output:
%chisquaretot, chi-square
%
%This file was written by Marco Mauri, 2019
%

function [chisquareData] = fitParameterspH(X,blackboxmodel,dataset,plotfigure)

clear muM
clear aceM
clear raceM
clear rglcM

%parameters
run_estimation = 0;
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP);

%clean parameters to estimate
parameters.par(7) = X(1); %Ta

% load data
if dataset==1
    loadedData = load('data/pH1data');
    Datay = loadedData.pH1data(:,2);
    Datax = loadedData.pH1data(:,1);
elseif dataset==2
    loadedData = load('data/pH2data');
    Datay = loadedData.pH2data(:,2);
    Datax = loadedData.pH2data(:,1);
end

% convert ace to g/L
DataxsA = parameters.par(23).*1e-3.*Datax;

for l=1:size(Datax,1)
    
    %set initial conditions
    parameters.x0(1) = 2.7; %glc g/L
    parameters.x0(2) = DataxsA(l,1); %ace g/L
    parameters.x0(3) = 0.1; %BP g/L
    parameters.x0(4) = 0; %H g/L
    parameters.x0(5) = 0; %BC g/L
    
    %solve batch dynamics
    s0 = parameters.x0;
    [~,r] = blackboxmodel(0,s0,parameters);
    
    muM(l,:) = r(1);
    rglcM(l,:) = r(3);
    raceM(l,:) = r(4)-r(5);
    
end

observedData = Datay./Datay(1);
expctedData = muM./muM(1,1);

%chisquare
chisquareData = sum( ((observedData-expctedData).^2)./expctedData );

if plotfigure==1
    figure(104)
    semilogx(DataxsA,expctedData,'-r','LineWidth',2);
    hold on
    grid on
    scatter(DataxsA,observedData);
    set (gcf,'units','points','position',[620,200,300,300])
    hold off
    legend(strcat('Ta = ',num2str(round(parameters.par(7),2))))
    xlabel('Acetate [g/L]')
    ylabel('Growth rate [1/h]')
    set(gca,'fontsize',12)
    set(gca,'LineWidth',1)
    drawnow
end
end


