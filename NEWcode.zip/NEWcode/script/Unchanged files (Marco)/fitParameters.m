%[chisquareData,Datax,observedData,expectedData] = fitParameters(X,blackboxmodel,parameters,Datax,Datay,dataset,run_estimation)
%computes the chi-square of a single data-set to obtain (Ta,n,Tg,m)
%
%Inputs:
%X, vector cotaining (Ta,n,Tg,m)
%blackboxmodel, is the model name
%run_estimation, 1 estimate parameters from data, 2 plot already existing estimation
%parameters, the structure containing the paramters values
%Datax, Datay, the dataset values
%dataset, the number of the dataset to use
%run_estimation, 1 estimate parameters from data, 2 plot already existing estimation
%
%Output:
%chisquareData, the chi-square of the dataset
%Datax,observedData, the experimental dataset values
%expectedData, the dataset values as predicted by the model
%
%This file was written by Marco Mauri, 2019
%

function [chisquareData,Datax,observedData,expectedData] = fitParameters(X,blackboxmodel,parameters,Datax,Datay,dataset,run_estimation)

clear muM
clear aceM
clear raceM
clear rglcM

%clean parameters to estimate
parameters.par(7) = X(1); %Ta
parameters.par(8) = X(2); %n
parameters.par(13) = X(3); %Tg
parameters.par(14) = X(4); %m

for l=1:size(Datax,1)
    
    %set initial conditions
    parameters.x0(1) = 2.7; %glc g/L
    parameters.x0(2) = Datax(l,1); %ace g/L
    parameters.x0(3) = 0.1; %BP g/L
    parameters.x0(4) = 0; %H g/L
    parameters.x0(5) = 0; %BC g/L
    
    %solve batch model
    s0 = parameters.x0;
    [~,r] = blackboxmodel(0,s0,parameters);
    
    muM(l,:) = r(1);
    rglcM(l,:) = r(3);
    raceM(l,:) = r(4)-r(5);
    
end

if dataset==1
    observedData = Datay;
    expectedData = rglcM;
elseif dataset==2
    observedData = Datay;
    expectedData = raceM;
elseif dataset==3
    observedData = Datay;
    expectedData = muM;
end

%chisquare
chisquareData = sum( ((observedData-expectedData).^2)./expectedData );

%plot
if run_estimation==1 && dataset==1

    subplot(1,3,2);
    semilogx(Datax,expectedData,'-r','LineWidth',3);
    hold on
    grid on
    scatter(Datax,observedData,50,'k','filled');
    %set (gcf,'units','points','position',[330,150,300,300])
    hold off
    legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
    xlabel('Acetate [g/L]')
    ylabel('Glc uptake rate [1/h]')
    set(gca,'fontsize',12)
    set(gca,'LineWidth',1)
    title('Main Figure 2C')
    drawnow
    hold off
    
elseif run_estimation==1 && dataset==2
    
    subplot(1,3,3);
    semilogx(Datax,expectedData,'-r','LineWidth',3);
    hold on
    grid on
    scatter(Datax,observedData,50,'k','filled');
    %set (gcf,'units','points','position',[650,150,300,300])
    hold off
    legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
    xlabel('Acetate [g/L]')
    ylabel('Net Ace uptake rate [1/h]')
    set(gca,'fontsize',12)
    set(gca,'LineWidth',1)
    title('Main Figure 2C')
    drawnow
    hold off
    
elseif run_estimation==1 && dataset==3
    
    %     figure('units','normalized','outerposition',[0 0 1 2/3])
    subplot(1,3,1);
    semilogx(Datax,expectedData,'-r','LineWidth',3);
    hold on
    grid on
    scatter(Datax,observedData,50,'k','filled');
    %set (gcf,'units','points','position',[0,150,300,300])
    hold off
    legend(strcat('Ta=',num2str(round(parameters.par(7),2)),' n=',num2str(round(parameters.par(8),1)),' Tg=',num2str(round(parameters.par(13),2)),' m=',num2str(round(parameters.par(14),1))),'Data')
    xlabel('Acetate [g/L]')
    ylabel('Growth rate [1/h]')
    set(gca,'fontsize',12)
    set(gca,'LineWidth',1)
    title('Main Figure 2C')
    drawnow
    hold off
    
end


end
