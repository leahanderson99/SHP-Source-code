%plot_dynamicsFedBatch(T,X,XnoC,parameters)
%plots the time evolution of B and H in the bioreactor operating in 
%fed-batch mode in the presence and absence of cleaner 
%
%Inputs:
%T time vector
%X = [G,A,BP,H,BC]; variables vector for the case with P and C
%XnoC = [G,A,BP,H,BC]; variables vector for the case without C
%parameters, the structure containing the paramters values
%
%Outputs:
%log-plot time-evelution of the fed-batch case for Btot and H in the
%presence and absence of cleaner
%
%This file was written by Marco Mauri, 2019
%

function plot_dynamicsFedBatch(T,X,XnoC,parameters)

plot(T,X(:,1),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(1,:));
plot(T,X(:,4),'--','LineWidth',0.8*parameters.plot(2),'Color',parameters.colors(7,:));
plot(T,X(:,3)+X(:,4),'--','LineWidth',1.2*parameters.plot(2),'Color',parameters.colors(3,:));
plot(T,XnoC(:,4),'-','LineWidth',0.8*parameters.plot(2),'Color',parameters.colors(7,:));
plot(T,XnoC(:,3)+XnoC(:,4),'-','LineWidth',1.2*parameters.plot(2),'Color',parameters.colors(3,:));
set(gca, 'YScale', 'log')
legend('G','H consortium','BP+H consortium','H producer','BP+H producer','Location','northwest')
xlabel('Time [h]')
ylabel('[g/L]')
set(gca,'FontSize',parameters.plot(1))
grid on
box on
axis tight

end
