%[chisquareTotal] = minimizeChiSquare(X,blackboxmodel,run_estimation)
%computes the total chi-square of the three sets of data used to obtain (Ta,n,Tg,m)
%
%Inputs:
%X, vector cotaining (Ta,n,Tg,m)
%blackboxmodel, is the model name
%run_estimation, 1 estimate parameters from data, 2 plot already existing estimation
%
%Output:
%chisquareTotal, total chi-square of the three sets of data
%
%This file was written by Marco Mauri, 2019
%

function [chisquareTotal] = minimizeChiSquare(X,blackboxmodel,run_estimation)

%parameters
batchChemFed = 0;
producer = 1;
cleaner = 0;
hproteinP = 0;
[parameters] = parameters_values(blackboxmodel,0,batchChemFed,producer,cleaner,hproteinP);

%load data and compute parameters
loadedData = load('script/data/EnjalbertRgup');
Datay = parameters.par(22).*1e-3.*loadedData.EnjalbertRgup(:,2);
Datax = parameters.par(23).*1e-3.*10.^loadedData.EnjalbertRgup(:,1);
[chisquareData1,DataxsA1,observedData1,expectedData1] = fitParameters(X,blackboxmodel,parameters,Datax,Datay,1,run_estimation);
loadedData = load('script/data/EnjalbertRace.mat');
Datay = parameters.par(23).*1e-3.*loadedData.EnjalbertRace(:,2);
Datax = parameters.par(23).*1e-3.*10.^loadedData.EnjalbertRace(:,1);
[chisquareData2,DataxsA2,observedData2,expectedData2] = fitParameters(X,blackboxmodel,parameters,Datax,Datay,2,run_estimation);
loadedData = load('script/data/EnjalbertMu.mat');
Datay = loadedData.EnjalbertMu(:,2);
Datax = parameters.par(23).*1e-3.*10.^loadedData.EnjalbertMu(:,1);
[chisquareData3,DataxsA3,observedData3,expectedData3] = fitParameters(X,blackboxmodel,parameters,Datax,Datay,3,run_estimation);

%chisquare
chisquareTotal = chisquareData1.^2+chisquareData2.^2+chisquareData3.^2;

%sava data
save('script/data/DataxsA1','-v6','DataxsA1')
save('script/data/observedData1','-v6','observedData1')
save('script/data/expctedData1','-v6','expectedData1')
save('script/data/DataxsA2','-v6','DataxsA2')
save('script/data/observedData2','-v6','observedData2')
save('script/data/expctedData2','-v6','expectedData2')
save('script/data/DataxsA3','-v6','DataxsA3')
save('script/data/observedData3','-v6','observedData3')
save('script/data/expctedData3','-v6','expectedData3')

end