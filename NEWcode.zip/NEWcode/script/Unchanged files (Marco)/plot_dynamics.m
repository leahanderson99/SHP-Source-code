%plot_dynamics(T,X,r,parameters)
%plots the time evolution of the variable (G,A,Bp,H,Bc)
%
%Inputs:
%T time vector
%X = [G,A,BP,H,BC]; variables vector
%r = [muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg]; internal rate vector
%parameters, the structure containing the paramters values
%
%Outputs:
%plots time evolutions of (G,A,Bp,H,Bc) and of the growth rates
%
%This file was written by Marco Mauri, 2019
%

function plot_dynamics(T,X,r,parameters)

figure('units','normalized','outerposition',[0 0 1 2/3])
subplot(1,2,1);
plot(T,X(:,1),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(1,:));
hold on
plot(T,X(:,2),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(2,:));
plot(T,X(:,3),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(3,:));
plot(T,X(:,4),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(7,:));
plot(T,X(:,5),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(4,:));
plot(T,X(:,6),'-','LineWidth',parameters.plot(2),'Color','m');
plot(T,X(:,3)+X(:,4),'--','LineWidth',parameters.plot(2),'Color',parameters.colors(3,:));
plot(T,X(:,5)+X(:,6),'--','LineWidth',parameters.plot(2),'Color',parameters.colors(4,:));
legend('G','A','BP','H','BC','HC','BP+H','BC+HC')
xlabel('Time [h]')
ylabel('[g/L]')
set(gca,'FontSize',parameters.plot(1)) %add 'Yscale, 'log' if needed
grid on
box on
axis tight
title('Dynamics of the consortium in chemostat with Hill function switching rate')
drawnow

subplot(1,2,2);
plot(T,r(:,1),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(3,:));
hold on
plot(T,r(:,2),'-','LineWidth',parameters.plot(2),'Color',parameters.colors(8,:));
legend('Growth Rate P','Growth Rate C')
xlabel('Time [h]')
ylabel('Growth Rate [1/h]')
set(gca,'FontSize',parameters.plot(1))
grid on
box on
axis tight
title('Growth rate in Batch Culture')
drawnow

end
