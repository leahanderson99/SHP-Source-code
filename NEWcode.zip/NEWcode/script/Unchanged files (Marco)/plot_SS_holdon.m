%plot_SS_holdon(parameters,SS,j,ylab,muhat)
%plots rgup at steady state as a function of D
%
%Inputs:
%parameters, the structure containing the paramters values
%SS is the array containing the variables and the rates at steady state for a specific Gin
%j is the entry of the vector SS to plot on the y axis, D is on the x axis
%ylab is the string of the y-label
%muhat is a rescaling factor to apply on the x axis
%
%Outputs:
%Plot rgup at steady-state as function of D 
%
%This file was written by Marco Mauri, 2019
%

function plot_SS_holdon(parameters,SS,j,ylab,muhat)

hold on

cl = 'k';
lw = parameters.plot(4);

xplot = SS(:,1);
yplot = SS(:,j);

intx = min(xplot(:,1)):(max(xplot(:,1))-min(xplot(:,1)))/(50*size(xplot,1)):max(xplot(:,1));
inty = interp1(xplot,yplot,intx,'pchip');
plot(intx./muhat,inty,'-','Color',cl,'LineWidth',lw)

xlabel('$\mu/\hat{\mu}$','Interpreter','latex')
ylabel(ylab)
grid on
box on
set(gca,'FontSize',parameters.plot(1))

end