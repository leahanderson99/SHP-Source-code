%plot_DGinMap
%plots the heat-map (D,Gin) coming form the steady-state analysis of 
%the consortium in chemostat operating in continuous mode
%
%Inputs:
%Ginplot, specify the value of Gin to use to produce the plots, if empty
%the maximum available is chosen
%parameters, the structure containing the paramters values
%
%Outputs:
%Plots of heat map D-Gin
%
%This file was written by Marco Mauri, 2019
%

function DGinPlots(Ginplot,parameters)
%% load rates and variables

load('script/data/solSSPC','solSSPC')
load('script/data/solSSPnoC','solSSPnoC')

%% select a specific Gin value

%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW

if isempty(Ginplot)
    Ginplot = solSSPC(end,2);
end

SS = solSSPC(solSSPC(:,2)==double(Ginplot),:);
SSnoC = solSSPnoC(solSSPnoC(:,2)==double(Ginplot),:);

%% plots

% [~,axF1] = plot_SS(parameters,SS,15+2,19+2,'r_{up}^g [g/gDW/h]');
% title(axF1,'Main Figure 5D')
% hold(axF1, 'off');  
% [~,axF2] = plot_SS(parameters,SS,16+2,20+2,'r_{over}^a [g/gDW/h]');
% title(axF2,'Supporting Figure S6B')
% hold(axF2, 'off');  
% [~,axF3] = plot_SS(parameters,SS,17+2,21+2,'r_{up}^a [g/gDW/h]');
% title(axF3,'Supporting Figure S6D')
% hold(axF3, 'off');  

aplot = SS(:,1);
bplot = SS(:,5)+SS(:,6);
% cplot = SS(:,7);
cplot = SS(:,7)+SS(:,8);
SSa = [aplot,bplot,cplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
[~,axF4] = plot_SS(parameters,SSa,2,3,'Btot [gDW/L]');
title(axF4,'Main Figure 5F')
hold(axF4, 'off');  

%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW

aplot = SS(:,1);
%bplot = SS(:,1).*SS(:,6);
bplot = SS(:,1).*SS(:,6)+SS(:,1).*SS(:,8);
SSa = [aplot,bplot,0.*aplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
aplot = SSnoC(:,1);
%bplot = SSnoC(:,1).*SSnoC(:,6);
bplot = SSnoC(:,1).*SSnoC(:,6)+SSnoC(:,1).*SSnoC(:,8);
SSnoCa = [aplot,bplot,0.*aplot,0.*aplot,SSnoC(:,5),0.*aplot,SSnoC(:,7)];
[~,axF5] = plot_SSCnoC(parameters,SSa,2,SSnoCa,2,'DHp+DHc [gDW/L/h]');
title(axF5,'Main Figure 6B')
hold(axF5, 'off');  

aplot = SS(:,1);
%bplot = SS(:,6)./Ginplot;
bplot = (SS(:,6)+SS(:,8))./Ginplot;
SSa = [aplot,bplot,0.*aplot,0.*aplot,SS(:,5),0.*aplot,SS(:,7)];
aplot = SSnoC(:,1);
%bplot = SSnoC(:,6)./Ginplot;
bplot = (SSnoC(:,6)+SSnoC(:,8))./Ginplot;
SSnoCa = [aplot,bplot,0.*aplot,0.*aplot,SSnoC(:,5),0.*aplot,SSnoC(:,7)];
[~,axF6] = plot_SSCnoC(parameters,SSa,2,SSnoCa,2,'(Hp+Hc)/G_{in} [gDW/g]');
title(axF6,'Main Figure 6C')
hold(axF6, 'off'); 

end


%SS = solSSPC(solSSPC(:,2)==double(Ginplot) & solSSPC(:,1)==double(Dinplot),:);