%[fig,axF] = plot_SS(parameters,SS,j,k,ylab)
%plots some steady-state results as a function of D
%
%Inputs:
%parameters, the structure containing the paramters values
%SS is the array containing the variables and the rates at steady state for a specific Gin
%i and j are the entries of the vector SS to plot on the y axis, D is on the x axis
%ylab is the string of the y-label
%
%Outputs:
%Plot i and j entries of the steady-state solution vector SS as function of D 
%fig and axF are the handler of the figure and the current axis
%
%This file was written by Marco Mauri, 2019
%

function [fig,axF] = plot_SS(parameters,SS,j,k,ylab)

fig = figure;
axF = axes('Parent', fig);
hold(axF, 'on');  

pBP = 5;
pBC = 7;
cl = parameters.colors(3,:); %green
cl2 = parameters.colors(8,:); %orange

psz = parameters.plot(3);
lw = parameters.plot(4);

xplot = SS(:,1);
yplot = SS(:,k);

intx = min(xplot(:,1)):(max(xplot(:,1))-min(xplot(:,1)))/(50*size(xplot,1)):max(xplot(:,1));
inty = interp1(xplot,yplot,intx,'pchip');
plot(intx,inty,'--','Color',cl2,'LineWidth',lw)

for i=1:size(SS,1)
    if SS(i,pBP)~=0 && SS(i,pBC)~=0
        s=scatter(SS(i,1),SS(i,k),psz,cl2,'filled','o');
        s.MarkerEdgeColor = cl2;
    elseif SS(i,pBP)~=0 && SS(i,pBC)==0
        s=scatter(SS(i,1),SS(i,k),psz,cl2,'filled','o');
        s.MarkerEdgeColor = cl2;
    elseif SS(i,pBP)==0 && SS(i,pBC)~=0
        s=scatter(SS(i,1),SS(i,k),psz,cl2,'filled','o');
        s.MarkerEdgeColor = cl2;
    elseif SS(i,pBP)==0 && SS(i,pBC)==0
        s=scatter(SS(i,1),SS(i,k),psz,'k','filled','o');
        s.MarkerEdgeColor = 'k';
    end
end

xplot = SS(:,1);
yplot = SS(:,j);

intx = min(xplot(:,1)):(max(xplot(:,1))-min(xplot(:,1)))/(50*size(xplot,1)):max(xplot(:,1));
inty = interp1(xplot,yplot,intx,'pchip');
plot(intx,inty,'-','Color',cl,'LineWidth',lw)

for i=1:size(SS,1)
    if SS(i,pBP)~=0 && SS(i,pBC)~=0
        s=scatter(SS(i,1),SS(i,j),psz,cl,'filled','o');
        s.MarkerEdgeColor = cl;
    elseif SS(i,pBP)~=0 && SS(i,pBC)==0
        s=scatter(SS(i,1),SS(i,j),psz,cl,'filled','o');
        s.MarkerEdgeColor = cl;
    elseif SS(i,pBP)==0 && SS(i,pBC)~=0
        s=scatter(SS(i,1),SS(i,j),psz,cl,'filled','o');
        s.MarkerEdgeColor = cl;
    elseif SS(i,pBP)==0 && SS(i,pBC)==0
        s=scatter(SS(i,1),SS(i,j),psz,'k','filled','o');
        s.MarkerEdgeColor = 'k';
    end
end

clear SSblack
for i=1:size(SS,1)
    if  SS(i,pBP)==0 && SS(i,pBC)==0
        SSblack(i,:) = [SS(i,1),SS(i,j)];
        s=scatter(SS(i,1),SS(i,j),psz,'k','filled','o');
        s.MarkerEdgeColor = 'k';
    end
end

SSblackU = unique(SSblack,'row');
SSblackU = SSblackU(any(SSblackU,2),:);
intx = min(SSblackU(:,1)):(max(SSblackU(:,1))-min(SSblackU(:,1)))/(50*size(SSblackU,1)):max(SSblackU(:,1));
inty = interp1(SSblackU(:,1),SSblackU(:,2),intx,'pchip');
plot(intx,inty,'-','Color','k','LineWidth',lw)

%oveflow threshold
%plot(intx,parameters.par(10).*ones(1,size(intx,2)),'--','Color','k','LineWidth',lw/2)

xlabel('D [1/h]')
ylabel(ylab)
grid on
box on
set(gca,'FontSize',parameters.plot(1))
drawnow

end