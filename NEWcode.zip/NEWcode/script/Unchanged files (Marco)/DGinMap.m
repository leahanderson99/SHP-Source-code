%DGinMap(run_heatmap,plot_heatmap,plot_rates)
%generates and plots the steady-state analysis of the consortium in chemostat
%operating in continuous mode by varying the values of the dilution rate D 
%and of the glucose inflow concentration Gin
%
%Inputs:
%run_heatmap, 0 does not computate the coexistence map, 1 computate the coexistence map, 2 just plot the already computed map  
%plot_heatmap, 0 does not plot the map, 1 plot the map
%plot_rates, 0 does not plot the rates plots, 1 plot the rates plots
%
%Outputs:
%Plots of heat map D-Gin and rates and yield for the maximal Gin computed
%in the simulations
%
%This file was written by Marco Mauri, 2019
%

function [sr] = DGinMap(run_heatmap,plot_heatmap,plot_rates,srBPtoBC,srBCtoBP,hproteinP, sr,m)    

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

if run_heatmap==1 || run_heatmap==2
% 
% define the model
blackboxmodel = @model;    

%parameters
run_estimation = 0; %0 import already estimated parameters (to speed up evaluation), 1 estimate parameters from data
batchChemFed = 1; %0 batch, 1 chemostat, 2 fedbatch
producer = 1; %0 without producer, 1 with producer
cleaner = 1; %0 without cleaner, 1 with cleaner
hproteinP = 1; %without H protein, 1 with H protein
[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP,srBPtoBC, srBCtoBP); 

end

%% simulation with producer and cleaner

if run_heatmap==1
    
hmh=msgbox('Please wait. Computation in progress...');

parameters.par(2) = 1;
parameters.par(3) = 1;

%generate grid
[heatmapparam] = create_heatmapparam();

%find the steady state solutions map
% solSSPC =
% [D,Gin,G,A,BP,H,BC;dG;dA;dBP;dH;dBC;muP;muC;rgupP;raoverP;raupP;rH;rgupC;raoverC;raupC;kdeg] OLD
% solSSPC =
% [D;Gin;G;A;BP;H;BC;HC;dG;dA;dBP;dH;dBC;dHC;muP;muC;rgupP;raoverP;raupP;rH;rgupC;raoverC;raupC;kdeg]
% NEW, added dHC

[solSSPC] = generateDGinMap(blackboxmodel,parameters,heatmapparam);
save('script/data/solSSPC','-v6','solSSPC')
sr(m).solSSPC = solSSPC;
%% simulation with producer and no cleaner
parameters.par(2) = 1;
parameters.par(3) = 0;

%generate grid
[heatmapparam] = create_heatmapparam();

%find the steady state solutions map
% solSS = [D,Gin,G,A,BP,H,BC;dG;dA;dBP;dH;dBC;muP;muC;rgupP;raoverP;raupP;rH;rgupC;raoverC;raupC;kdeg]
[solSSPnoC] = generateDGinMap(blackboxmodel,parameters,heatmapparam);
save('script/data/solSSPnoC','-v6','solSSPnoC')
sr(m).solSSPnoC = solSSPnoC;
if isvalid(hmh); delete(hmh); end

end

%% plot D Gin map
if plot_heatmap ==1 || run_heatmap==2
    plot_DGinMap
end

%plots values of variables
if plot_rates==1 || run_heatmap==2
    Ginplot = [];
    DGinPlots(Ginplot,parameters)
end

end