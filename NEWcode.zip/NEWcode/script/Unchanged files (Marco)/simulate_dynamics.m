%[T,X,dx,r] = simulate_dynamics(blackboxmodel,parameters,tspan,s0)
%generates the time evolution of the variable (G,A,Bp,H,Bc)
%
%Inputs:
%blackboxmodel, is the model name
%parameters, the structure containing the paramters values
%tspan, input time vector
%s0, initial conditions for (G,A,Bp,H,Bc)
%
%Outputs:
%T time vector
%X = [G,A,BP,H,BC]; variables vector
%dx = [dG,dA,dBP,dH,dBC]; rate vector
%r = [muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg]; internal rate vector
%
%This file was written by Marco Mauri, 2019
%

function [T,X,dx,r] = simulate_dynamics(blackboxmodel,parameters,tspan,s0)

roundingN = 5;

%solve ODE
odeOptions = odeset('RelTol',1e-6,'NonNegative',[1:size((s0),2)]);
[T, X] = ode15s(@(t, x) blackboxmodel(t, x, parameters), tspan,s0,odeOptions);

%round for too small values
X =  double(vpa(round(X,roundingN))); 

%remove eventual negative solutions due to numerical errors
Xt = 0.*X;
X = X(all(X >=0, 2), :);

%remove eventual imaginary roots due to numerical errors
row = find(prod(imag(X)==0,2));
X = X(row,:);

%remove eventual numerical error on H
if parameters.par(4)*parameters.par(2)==0
    X = X(all(X(:,4)==parameters.x0(1,4),2),:);
end

if isempty(X)
    X=Xt;
end

%find rates
dx = zeros(size(X,1),size(X,2));
r = zeros(size(X,1),10);
for i=1:size(X)
    [dx(i,:),r(i,:)] = blackboxmodel(T(i,:),X(i,:),parameters);
end

end