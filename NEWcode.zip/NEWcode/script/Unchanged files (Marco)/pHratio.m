%[pHratioValue] = pHratio(blackboxmodel)
%computes the ratio of the parameter Ta at two different pH values: Ta(pH1)/Ta(pH2)
%
%Inputs:
%blackboxmodel, is the model name
%
%Output:
%pHratioValue, the value Ta(pH1)/Ta(pH2)
%
%This file was written by Marco Mauri, 2019
%

function [pHratioValue] = pHratio(blackboxmodel)

% fit first dataset
lb = [0.1];
X0 = [4];
ub = [8];
options = optimset('Display','off');
[fittedpH1] = fmincon(@(X) minimizeChiSquarepH(X,blackboxmodel,1),X0,[],[],[],[],lb,ub,[],options);

% fit second dataset
lb = [0.1];
X0 = [0.8];
ub = [8];
[fittedpH2] = fmincon(@(X) minimizeChiSquarepH(X,blackboxmodel,2),X0,[],[],[],[],lb,ub,[]);

% pH ratio
pHratioValue = fittedpH1/fittedpH2;

end


