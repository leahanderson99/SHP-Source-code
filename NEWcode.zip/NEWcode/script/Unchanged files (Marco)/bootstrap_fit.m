%bootstrap_fit(run_bootstrap)
%performs the a-posteriori identifiability analysis on the fitted paramters (Tg,n,Ta,m)
%
%Input:
%run_bootstrap, 0 suppresses the a-posteriori identifiability analysis of the estimated parameters,
%1 performs the a-posteriori identifiability analysis via bootstrapping and
%plots the results, 2 imports a previously saved analysis and plots the results
%
%The script defines the differential equation of the model
%loads the experimental data
%generates 1000 new datasets
%fits the data
%plots the result
%
%This file was written by Marco Mauri, 2019
%

function bootstrap_fit(run_bootstrap)

addpath(genpath('script/FMINSEARCHBND'));
addpath(genpath('script/data'))

if run_bootstrap==1
    
    %define the model
    blackboxmodel = @Model;
    
    %initialize
    lb = [0.2,              0.2,          0.05,     0.2];
    X0 = [3.52,           1,       0.25,   1];
    ub = [5,                3,            1,        3];
    
    %load data
    load('script/data/DataxsA1','DataxsA1')
    load('script/data/observedData1','observedData1')
    load('script/data/expectedData1','expectedData1')
    load('script/data/DataxsA2','DataxsA2')
    load('script/data/observedData2','observedData2')
    load('script/data/expectedData2','expectedData2')
    load('script/data/DataxsA3','DataxsA3')
    load('script/data/observedData3','observedData3')
    load('script/data/expectedData3','expectedData3')
    
    % generate residuals
    resid1 = expectedData1 - observedData1;
    resid2 = expectedData2 - observedData2;
    resid3 = expectedData3 - observedData3;
    
    % shuffle and generate new datasets
    len=1000;
    yshuff1 = zeros(len,length(resid1));
    for i=1:len
        yshuff1(i,:) = expectedData1 + resid1(randperm(length(resid1)));
    end
    
    yshuff2 = zeros(len,length(resid2));
    for i=1:len
        yshuff2(i,:) = expectedData2 + resid2(randperm(length(resid2)));
    end
    
    yshuff3 = zeros(len,length(resid3));
    for i=1:len
        yshuff3(i,:) = expectedData3 + resid3(randperm(length(resid3)));
    end
    
    %% refit
    options = optimset('TolFun',1e-2,'TolX',1e-2,'MaxIter',100,'Display','off');
    
    fittedParametersBoot = zeros(len,length(X0));
    for i=1:size(fittedParametersBoot,1)
        fprintf('Iteration %d \n',size(fittedParametersBoot,1)-i)
        [fittedParametersBoot(i,:)] = fminsearchbnd(@(X0) minimizeChiSquareBoot(X0,blackboxmodel,DataxsA1,yshuff1(i,:)',DataxsA2,yshuff2(i,:)',DataxsA3,yshuff3(i,:)'),X0,lb,ub,options);
    end
    save('script/data/fittedParametersBoot','-v6','fittedParametersBoot')
    
end

%% plot

if run_bootstrap==1 || run_bootstrap==2
    load('script/data/fittedParametersBoot','fittedParametersBoot')
    load('script/data/fittedParameters','fittedParameters')
    fig = figure;
    axF = axes('Parent', fig);
    hold(axF, 'on');
    boxplot(fittedParametersBoot./fittedParameters,'Labels',{'Ta','n','Tg','m'})
    ylim([0 2])
    h=findobj(gca,'tag','Outliers');
    delete(h)
    title(axF,'Supporting Figure S1')
    drawnow
    hold(axF, 'off');
end
end