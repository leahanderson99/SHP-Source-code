%[chisquaretot] = minimizeChiSquarepH(X,blackboxmodel,dataset)
%computes the total chi-square of the three sets of data used to obtain (Ta,n,Tg,m)
%
%Inputs:
%X is Ta
%blackboxmodel, is the model name
%dataset, is the dataset number
%
%Output:
%chisquaretot, chi-square
%
%This file was written by Marco Mauri, 2019
%

function [chisquaretot] = minimizeChiSquarepH(X,blackboxmodel,dataset)

plotfigure = 0;
[chisquare] = fitParameterspH(X,blackboxmodel,dataset,plotfigure);

chisquaretot = chisquare.^2;

end