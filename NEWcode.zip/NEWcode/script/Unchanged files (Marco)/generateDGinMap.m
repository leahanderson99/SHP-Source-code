%[solSS] = generateDGinMap(blackboxmodel,parameters,heatmapparam)
%generates the heat-map (D,Gin) of the stable steady-state analysis of the 
%consortium in chemostat operating in continuous mode by varying the values 
%of the dilution rate D and of the glucose inflow concentration Gin
%
%Inputs:
%blackboxmodel, is the model name
%parameters, the structure containing the paramters values
%heatmapparam, structure with the grid (D,Gin)
%
%Outputs:
%solSS = [D,Gin,G,A,BP,H,BC,dG,dA,dBP,dH,dBC,muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg]
%is the array containing the variables and the rates at steady state for a specific (D,Gin)
%
%This file was written by Marco Mauri, 2019
%

function [solSS] = generateDGinMap(blackboxmodel,parameters,heatmapparam)

%entry numbers in the parameter structure of the varying variables
Dx = 26;
Giny = 27;

%initialize grid
Din = heatmapparam.Din;
Dfin = heatmapparam.Dfin;
Dstep = heatmapparam.Dstep;

Gin = heatmapparam.Gin;
Gfin = heatmapparam.Gfin;
Gstep = heatmapparam.Gstep;

%store varying variables
Dtemp = parameters.par(Dx);
Gtemp = parameters.par(Giny);

%compute unique stable solution
clear solSS
for k=1:round((Dfin-Din)/Dstep)
    parameters.par(Dx) = Din+(k-1)*Dstep;
    
    for j=1:round((Gfin-Gin)/Gstep)
        parameters.par(Giny) = Gin+(j-1)*Gstep;
        fprintf('Iteration %d: D %f Subiteration %d: Gin %f\n',(round((Dfin-Din)/Dstep)-k),parameters.par(Dx),(round((Gfin-Gin)/Gstep)-j),parameters.par(Giny))
        
        %find the unique Stable Solution
        [sol,solRates] = findStableSolution(blackboxmodel,parameters);
        %disp(sol)
        fprintf('G %f A %f BP %f H %f BC %f HC %f\n \n',sol(1),sol(2),sol(3),sol(4),sol(5),sol(6))
        
        solSSt = [parameters.par(Dx),parameters.par(Giny),sol,solRates];
        
        if ~exist('solSS','var')
           solSS = solSSt;
        else
           solSS = [solSS;solSSt];
        end
        
    end
end

%set back to original values
parameters.par(Dx) = Dtemp;
parameters.par(Giny) = Gtemp;

end

