%[sol,solRates] = findStableSolution(blackboxmodel,parameters)
%finds the unique stable solution at steady state of the 
%consortium in chemostat operating in continuous mode for a specific value 
%of the dilution rate D and of the glucose inflow concentration Gin
%
%Inputs:
%blackboxmodel, is the model name
%parameters, the structure containing the paramters values
%
%Outputs:
%sol = [G,A,BP,H,BC], variable vector at steady state
%solRates =
%[dG,dA,dBP,dH,dBC,muP,muC,rgupP,raoverP,raupP,rH,rgupC,raoverC,raupC,kdeg],
%rates vector at steady state
%
%This file was written by Marco Mauri, 2019
%

function [sol,solRates] = findStableSolution(blackboxmodel,parameters)

%arbitrary initial values
glcv = 0;
acev = 0;
bpv = parameters.par(2).*parameters.par(27)./2;
hv = 0;
bcv = parameters.par(3).*parameters.par(27)./2;
hcv = 0;

%solve ODE
s0=double(vpa([glcv,acev,bpv,hv,bcv, hcv]));
sol = s0;
if ~isequal(double(vpa(s0)),[0,0,0,0,0,0])
    tspan = 0:2500000:10000000;
    [~,X,dx,r] = simulate_dynamics(blackboxmodel,parameters,tspan,s0);
    sol = X(end,:);
    solRates = [dx(end,:),r(end,:)];
else
    sol = 0.*s0;
    solRates = zeros(1,6+10);%[0.*dx,0.*r];
end

%check
if isempty(sol)
    %sol = [0,parameters.par(29),0,0,0,parameters.x0(6)];
    sol = 0.*s0;
    solRates = zeros(1,6+10);%[0.*dx,0.*r];
end

end
