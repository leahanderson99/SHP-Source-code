%Plots a phase diagram of srBPtoBc against srBCtoBP, indicating regions of
%coexistence of the cleaner and producer strain to summarise results in a
%compact way
% This file was written by Leah Anderson, 2021

function plot_SRMap

load('script/data/sr','sr')
%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW

sizep=170;
markertype='o';

%% figure regarding the coexistence of Producer and Cleaner

fig = figure;
axF = axes('Parent', fig);
hold(axF, 'on');  
hms=msgbox('Please wait. Plotting switching rate PD..');

D = 0.55;
Gin= 20;
str1 = sprintf('%0.2f' , D);
str2 = sprintf('%0.0f' , Gin);

                                                                            
iend=289;
for i=1:iend                                                                  % set iend equal to the size of the data structure
    sr(i).solSSPC = sr(i).solSSPC(132,[1 2 5 7]);                                       %extracting only row 100 and columns 1,2,5,7 from solSSPC data field (D =0.15, Gin=20, Bp, Bc)
    %disp(sr(i).solSSPC);
    srBPtoBC = sr(i).storesr(1); 
    srBCtoBP = sr(i).storesr(2);
    if sr(i).solSSPC(3)==0 && sr(i).solSSPC(4)==0                                                 %scatter(x,y,size,colour,'filled',markertype)
        scatter(srBPtoBC,srBCtoBP,sizep,'k','filled',markertype, 'DisplayName', 'washout')           %k arg specifies the data point colour, why not just set to black for Bc,Bp=0? 
    
    elseif sr(i).solSSPC(3)~=0 && sr(i).solSSPC(4)~=0                                             %pink pts for coexistence
        scatter(srBPtoBC,srBCtoBP,sizep,rgb('pink'),'filled',markertype, 'DisplayName', 'coexistence')
    
    elseif sr(i).solSSPC(3)==0 && sr(i).solSSPC(4)~=0                                             %blue pts for cleaner only
        scatter(srBPtoBC,srBCtoBP,sizep,rgb('bright blue'),'filled', markertype, 'DisplayName', 'cleaner only')
    
    elseif sr(i).solSSPC(3)~=0 && sr(i).solSSPC(4)==0                                             %green pts for producer only
        scatter(srBPtoBC,srBCtoBP,sizep,rgb('fresh green'),'filled', markertype,'DisplayName', 'producer only' )            
                                                                                            
    end
    hold(axF, 'on'); 
end

xlabel('srPtoC')
ylabel('srCtoP')
grid on
box on
set(gca,'FontSize',22)
pbaspect([1 1 1])
axis tight
%legend('washout','coexistence', 'cleaner only', 'producer only')
title(['D=', str1])
drawnow
hold(axF, 'off'); 

if isvalid(hms); delete(hms); end


end