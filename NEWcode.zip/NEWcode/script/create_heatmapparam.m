%[heatmapparam] = create_heatmapparam()
%generates a structure containing the grid of points (D,Gin) used to
%simulate the system at steady state 
%
%Output:
%heatmapparam, structure with the grid (D,Gin)
%
%This file was written by Marco Mauri, 2019
%

function [heatmapparam] = create_heatmapparam()
heatmapparam = struct();

heatmapparam.Din = 0;
heatmapparam.Dfin = 0.802;
heatmapparam.Dstep = 0.02;

heatmapparam.Gin = 0;
heatmapparam.Gfin = 20.5;
heatmapparam.Gstep = 0.5;

% heatmapparam.Din = 0;
% heatmapparam.Dfin = 0.705;
% heatmapparam.Dstep = 0.05;
% 
% heatmapparam.Gin = 0;
% heatmapparam.Gfin = 22.5;
% heatmapparam.Gstep = 2;

end