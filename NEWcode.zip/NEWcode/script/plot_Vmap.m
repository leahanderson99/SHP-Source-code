%Plots a phase diagram of V1 against V2 for the Hill function switching rates, indicating regions of
%coexistence of the cleaner and producer strain to summarise results in a
%compact way
%% This file was written by Leah Anderson, 2021
function plot_Vmap

load('script/data/sr','sr')
%solSSPC
%=[D,Gin,G,A,BP,H,BC,HC,dG,10 dA,dBP,dH,dBC,dHC,15 muP,muC,rgupP,raoverP,raupP,20 rH,rgupC,raoverC,raupC,24 kdeg] NEW

sizep=100;
markertype='o';

%% figure regarding the coexistence of Producer and Cleaner

fig = figure;
axF = axes('Parent', fig);
hold(axF, 'on');  
hms=msgbox('Please wait. Plotting V1/V2 PD..');

D = 0.45;                                                   %change this manually so correct value displays in plot title
Gin= 20;
str1 = sprintf('%0.2f' , D);
str2 = sprintf('%0.0f' , Gin);
                                                                        
iend=289;                 %must equal the number of rows in the current data structure (sr)
for i=1:iend                                                                  
    sr(i).solSSPC = sr(i).solSSPC(1,[1 2 5 7]);                                       %extracting only row X and columns 1,2,5,7 from solSSPC data field (D, Gin=20, Bp, Bc)
    %disp(sr(i).solSSPC);
    V1 = sr(i).storesr(1); 
    V2 = sr(i).storesr(2);
    if sr(i).solSSPC(3)==0 && sr(i).solSSPC(4)==0                                                 %scatter(x,y,size,colour,'filled',markertype)
        scatter(V1,V2,sizep,'k','filled',markertype, 'DisplayName', 'washout')           
    
    elseif sr(i).solSSPC(3)~=0 && sr(i).solSSPC(4)~=0                                             %pink pts for coexistence
        scatter(V1,V2,sizep,rgb('pink'),'filled',markertype, 'DisplayName', 'coexistence')
    
    elseif sr(i).solSSPC(3)==0 && sr(i).solSSPC(4)~=0                                             %blue pts for cleaner only
        scatter(V1,V2,sizep,rgb('bright blue'),'filled', markertype, 'DisplayName', 'cleaner only')
    
    elseif sr(i).solSSPC(3)~=0 && sr(i).solSSPC(4)==0                                             %green pts for producer only
        scatter(V1,V2,sizep,rgb('fresh green'),'filled', markertype,'DisplayName', 'producer only' )            
                                                                                            
    end
    hold(axF, 'on'); 
end

xlabel('V1')
ylabel('V2')
grid on
box on
set(gca,'FontSize',15)
pbaspect([1 1 1])
axis tight
%legend('washout','coexistence', 'cleaner only', 'producer only')
title(['Phase diagram for Hill function switching rates with D=', str1, ',Gin=', str2])
drawnow
hold(axF, 'off'); 

if isvalid(hms); delete(hms); end


end

