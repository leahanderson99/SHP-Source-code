%[parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP)
%creates the structure containing the values of the parameters
%
%Inputs:
%blackboxmodel, is the model name
%run_estimation, 0 imports already estimated parameters (to speed up evaluation), 1 estimate parameters from data, 2 plot already existing estimation
%batchChemFed, 0 simulates batch, 1 chemostat, 2 fedbatch
%producer, 0 simulation without producer, 1 with producer
%cleaner, 0 simulation without cleaner, 1 with cleaner
%hproteinP, 0 simulation without H protein, 1 with H protein
%
%Output:
%parameters, the structure containing the paramters values
%
%This file was written by Marco Mauri, 2019
%

function [parameters] = parameters_values(blackboxmodel,run_estimation,batchChemFed,producer,cleaner,hproteinP,K1)  %srBPtoBC, srBCtoBP)  %

%varying parametrs
if batchChemFed == 2 || batchChemFed == 0
    D = batchChemFed*0; %1/h dilution rate in batch
    Gin = batchChemFed*0; %g/L glucose feed in batch
else
    D = batchChemFed*0.05; %1/h dilution rate in chemostat
    Gin = batchChemFed*20; %g/L glucose feed in chemostat
end

G0Batch = 2.7; %g/L glucose at t=0 for batch simulation
G0fedBatch = 20; %g/L

%from the literature
alphaglc = 180; %g/mol
Kg = alphaglc.*5e-4; %g/L
alphaace = 59.04; %g/mol
Ka = alphaace.*8.5e-3; %g/L
Cm = 0.01; %g/gDW/h         
Yh = 0.2; %adimensional
KACS = alphaace.*0.2e-3; %g/L

%from experiments at exponential steady state either on glucose...
GLCmu = 0.61; %1/h
GCLrgup = 1.48; %g/gDW/h
GLCraover = 0.13; %g/gDW/h
GLCg = 2.7; %g/L
GLCl = 0.7; %1/h

%... or on acetate
ACEraup = 0.82; %1/h
ACEmu = 0.24; %1/h
ACEa = 2.65; %g/L

%fit at exponential steady state
kg = GCLrgup*((GLCg+Kg)/GLCg); %g/GDW/h
l = GLCl; %g/GDW/h
kover = GLCraover/(GCLrgup-l); %adimensional
ka = ACEraup*((ACEa+Ka)/ACEa); %g/GDW/h
Ya = (ACEmu+(GLCmu.*Cm)/(GCLrgup-Cm)).*(1/(ACEraup-(GLCraover.*Cm)/(GCLrgup-Cm))); %gDW/g
Yg = (GLCmu+Ya.*GLCraover)/(GCLrgup-Cm); %gDW/g
kdeg = Cm*Yg; %1/h
kDPTS = kg/4; %g/GDW/h
kACS = 1.5*ka; %g/GDW/h

%run a fit to fix the remaining parameters
if run_estimation==1
    %fit data and obtain parameters values
    [fittedParameters] = findParameters(blackboxmodel,run_estimation);
    %rescale Ta according to pH
    [pHratioValue] = pHratio(blackboxmodel);
    %parameters
    Ta = fittedParameters(1)/pHratioValue; %g/L
    n = fittedParameters(2);
    Tg = fittedParameters(3); %g/L
    m = fittedParameters(4);
elseif run_estimation==2
    plot_parametersfit(blackboxmodel)
    Ta = 0.52; %3.5/6.69; %g/L
    n = 1;
    Tg = 0.25; %g/L
    m = 1;
else
    Ta = 0.52; %3.5/6.69; %g/L
    n = 1;
    Tg = 0.25; %g/L
    m = 1;
end

%initial values
G0 = 0;
A0 = 0;
BP0 = producer*0.1;
H0 = producer*0;
BC0 = cleaner*0.1;
HC0 = cleaner*0;

if batchChemFed==0
    G0 = G0Batch;
elseif batchChemFed==2
    G0 = G0fedBatch;
end

sz=15; %font size
lw=3.5; %line width
sz2=40; %font size
lw2=3; %line width
bl = [0 0.4470 0.7410];
rd = [233/255 72/255 73/255];
gr = [0.4660 0.6740 0.1880];
og = [255/255 153/255 51/255];
bk = [0/255 0/255 0/255];
br = [175/255 103/255 61/255];
vl = [173/255 113/255 181/255];
orange = [1 0.5 0];

%store parameters in structure
parameters = struct();
parameters.par = [batchChemFed,producer,cleaner,hproteinP,kg,Kg,Ta,n,kover,l,ka,Ka,Tg,m,Yg,Ya,Yh,Cm,kDPTS,kACS,KACS,alphaglc,alphaace,kdeg,G0Batch,D,Gin,G0fedBatch,K1]; %cleaner*srBPtoBC,cleaner*srBCtoBP]; 
parameters.x0 = [G0,A0,producer*BP0,producer*H0,cleaner*BC0,cleaner*HC0];
parameters.plot = [sz,lw,sz2,lw2];
parameters.colors = [bl;rd;gr;og;bk;br;vl;orange];

end