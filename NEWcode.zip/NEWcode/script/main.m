%main(run_estimation,run_heatmap,run_bootstrap)
%performs the anlysis and plots the results regarding the paper
%``Enhanced production of heterologous proteins by a synthetic microbial 
%community: Conditions and trade-offs'',
%Marco Mauri, Jean-Luc Gouz�, Hidde de Jong, Eugenio Cinquemani
%
%Inputs:
%run_estimation, 0 imports already estimated parameters (to speed up evaluation) without plotting the results, 
%1 estimates parameters from data and plots the results, 2 plots a previously stored estimation and imports the estimated parameters
%run_heatmap, 0 does not produce the steady state analysis as function of (D,Gin),
%1 estimates the steady states and plots the results, 2 plots a previously stored analysis
%run_bootstrap, 0 suppresses the a-posteriori identifiability analysis of the estimated parameters,
%1 performs the a-posteriori identifiability analysis via bootstrapping and
%plots the results, 2 imports a previously saved analysis and plots the results 
%
%This file was written by Marco Mauri, 2019
%% and modified by Leah Anderson, 2021

function main(run_estimation,run_heatmap,run_bootstrap)

%% add paths
addpath(genpath('script'));

% %% dynamics
batchChemFed = 1; %0 batch, 1 chemostat, 2 fedbatch
producer = 1; %0 without producer, 1 with producer
cleaner = 1; %0 without cleaner, 1 with cleaner
hproteinP = 1; %0 without H protein, 1 with H protein;
%srBPtoBC = 0.0; 
%srBCtoBP = 0.0;
K1 = 0.0001;
% [T,X,dx,r] = dynamics(run_estimation,batchChemFed,producer,cleaner,hproteinP,srBPtoBC, srBCtoBP);   %V1,V2

% % % plotting Hill fn phase diagram and Protein production/yield figures
blackboxmodel = @test;
[parameters] = parameters_values(blackboxmodel, run_estimation,batchChemFed,producer,cleaner,hproteinP,K1); %srBPtoBC,srBCtoBP);
% plot_SRMap
% % % % plot_DGinMapSR
DGinPlotsSR(20,parameters)
% plot_Vmap
% 
% % % % extracting maximum yield and productivity values from data structures
% load('script/data/sr','sr')
% aend = 289;
% ctr=1;
% i=1:1:aend;
% difference =zeros(1,numel(i));
% srPtoC=zeros(1,numel(i));
% srCtoP=zeros(1,numel(i));
% maxplane = zeros(1,numel(i));
% product_noc = zeros(1,numel(i));
% Maxb = zeros(1,numel(i));
% MaxDb = zeros(1,numel(i));
% Maxp=zeros(1,numel(i)); % preallocating zero vectors
% for a = 1:aend
%     solSSPC = sr(a).solSSPC;
%     solSSPnoC = sr(a).solSSPnoC;
%     srPtoC(ctr) = sr(a).storesr(1);
%     srCtoP(ctr) = sr(a).storesr(2);
%     %str1 = sprintf('%0.2f' ,srPtoC);
%     %str2 = sprintf('%0.2f' ,srCtoP);
%     productivity = solSSPC(:,1).*solSSPC(:,6)+solSSPC(:,1).*solSSPC(:,8);
%     %yield = (solSSPC(:,6)+solSSPC(:,8))./solSSPC(:,2);
%     Dbiomass = solSSPC(:,1).*(solSSPC(:,5)+solSSPC(:,7));
%     biomass = (solSSPC(:,5)+solSSPC(:,7));
%     Maxb(ctr) = max(biomass);
%     MaxDb(ctr) = max(Dbiomass);
%     Maxp(ctr) = max(productivity);
%     maxplane(ctr) = 0.6850;
%     [M,I] = max(productivity);
%     product_noc(ctr) = solSSPnoC(I,1).*solSSPnoC(I,6)+solSSPnoC(I,1).*solSSPnoC(I,8);
%     difference(ctr) = Maxp(ctr) - product_noc(ctr);
%     ctr=ctr+1;
%     %Maxy = sprintf('%0.4f', max(yield));
%     %disp(z)
% end

% %saving data as doubles
% x = srPtoC;
% save('script/data/x','-v6','x')
% 
% y = srCtoP;
% save('script/data/y','-v6','y')
% 
% z = Maxp;
% save('script/data/z','-v6','z')
% save('script/data/maxplane','-v6','maxplane')
% save('script/data/difference','-v6','difference')
% save('script/data/Maxb','-v6','Maxb')
% save('script/data/MaxDb','-v6','MaxDb')

%generating 3d line plots
% plot3(srPtoC,srCtoP,Maxp,'o', 'Color','b','MarkerSize',10,'MarkerFaceColor','#D9FFFF')
% % hold on
% % plot3(srPtoC,srCtoP,maxplane)
% xlabel('srPtoC');
% ylabel('srCtoP');
% zlabel('Maximum productivity');

%generate hill fn data:
% if run_heatmap==1 || run_heatmap==2
%     plot_heatmap =0;
%     plot_rates = 0;
%     sr = struct();
%     kend= 3;
%     m=1;
%     for k = 1:kend
%         K1 = 0.0026 + 0.005*k;   
%         sr(m).storesr = [K1];
%         [sr]= HillDGinMap(run_heatmap,plot_heatmap,plot_rates,K1, hproteinP, sr,m); 
%         m = m+1;
%     end
%     save('script/data/sr','-v6','sr')
% end


% 
% % 
% % % % switching rate map
% if run_heatmap==1 || run_heatmap==2
%     plot_heatmap =0;
%     plot_rates = 0;
%     sr = struct();
%     kend= 0;
%     m = 1; %change to 1
%     iend = 0;
%     for k = 0:kend
%         srBPtoBC = 0.10 + k*0.04;
%         for i= 0:iend
%         srBCtoBP = 0.10 + i*0.04;
%         sr(m).storesr = [srBPtoBC, srBCtoBP];
%         [sr]= DGinMap(run_heatmap,plot_heatmap,plot_rates, srBPtoBC, srBCtoBP,hproteinP, sr, m);
%         m = m+1;
%         end
%     end
%     save('script/data/sr','-v6','sr')
% end

%% generate a-posteriori identifiability analysis
%if run_bootstrap==1 || run_bootstrap==2
%   bootstrap_fit(run_bootstrap)
%end

end
